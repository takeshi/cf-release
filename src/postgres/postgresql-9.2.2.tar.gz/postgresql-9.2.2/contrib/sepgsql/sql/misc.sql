--
-- Regression Test for Misc Permission Checks
--

LOAD '$libdir/sepgsql';		-- failed
